<?php
require_once __DIR__ . '/../models/User.php';

class UserController
{
    public static function register()
    {
        $error = "";
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username']);
            $email = trim($_POST['email']);
            $password = $_POST['password'];

            if (strlen($username) < 3 || strlen($username) > 50) {
                $error = "The login must contain between 3 and 50 characters.";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Incorrect email.";
            } elseif (strlen($password) < 6) {
                $error = "The password must be at least 6 characters long.";
            } else {
                $result = User::register($username, $email, $password);
                if ($result === true) {
                    header('Location: index.php?action=login');
                    exit;
                } else {
                    $error = $result;
                }
            }
        }

        include __DIR__ . '/../views/register.php';
    }
    public static function login()
    {
        $error = "";
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username']);
            $password = $_POST['password'];

            $result = User::login($username, $password);
            if ($result === true) {
                header('Location: index.php?action=category_list');
                exit;
            } else {
                $error = $result;
            }
        }

        include __DIR__ . '/../views/login.php';
    }
    public static function logout()
    {
        session_destroy();
        header('Location: index.php?action=login');
        exit;
    }
}
